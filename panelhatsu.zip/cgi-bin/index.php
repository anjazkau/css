<html>
<head>
<script language="JavaScript">window.alert('Bantu Follow Instagram Gw');window.location.href='https://instagram.com/hatsu_host?igshid=YmMyMTA2M2Y=';</script>
</head>
<body></body>
</html>