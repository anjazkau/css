<?php 
$nik = "WEB HATSU HOST II";
$sender = "admin@suport.co.id";
?>