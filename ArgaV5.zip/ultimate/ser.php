<?php 

$nik = "Arga Ultimate";
$sender = "admin@argaultimate.id";
?>