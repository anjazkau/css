<?php 
$nik = "manyu store";
$sender = "admingans@xx.com";
?>