<?php 
$nik = "RESSULTS MARGA NF";
$sender = "esemtepeh@mail.smtpiph.net";
?>