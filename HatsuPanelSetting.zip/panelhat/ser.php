<?php 

$nik = "WEB HATSU HOST ||";
$sender = "admin@support.id";
?>