<?php
$dataFile = 'data.json';
$configFile = 'config.php';

$data = json_decode(file_get_contents($dataFile), true);
$config = include $configFile;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $maxTime = isset($_POST['maxTime']) ? (int)$_POST['maxTime'] * 60 : 3600; // Mengubah ke detik

    if (count($data) >= $config['max_emails']) {
        echo json_encode(['success' => false, 'message' => 'Mau Nambah Ya Bayar Goblok!!.']);
        exit;
    }

    // Menambahkan data baru
    $data[] = ['email' => $email, 'timestamp' => time(), 'maxTime' => $maxTime];
    file_put_contents($dataFile, json_encode($data));

    echo json_encode(['success' => true, 'message' => 'Email Berhasil Ditambahkan.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal Kurang Ganteng.']);
}
?>
