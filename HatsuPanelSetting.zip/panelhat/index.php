<?php
include 'ser.php';
$config = include 'config.php';
$expiration_config = include 'expiration_config.php';

if ($expiration_config && isset($expiration_config['expiration_datetime'])) {
    $expiration_date_str = $expiration_config['expiration_datetime'];

    if (!empty($expiration_date_str)) {
        $expiration_datetime = new DateTime($expiration_date_str);
        $current_time = new DateTime();

        if ($current_time > $expiration_datetime) {
            header('Location: exp.php');
            exit;
        }
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>HATSU HOST</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="canonical" href="https://x-tools.my.id">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ramabhadra&family=Tilt+Neon&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.16/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
</head>
<body class="font-sans-serif p-4 bg-gray-900 text-sm" style="font-family: 'Ramabhadra', sans-serif; font-family: 'Tilt Neon', sans-serif; padding-top: 5rem;">
    <div class="form-container max-w-full mx-auto bg-gray-800 text-white text-center rounded-lg shadow-lg p-6 mt-6">
        <img src="https://i.ibb.co.com/WnSpqsc/20230812-141841-removebg-preview-1.png" style="transform:scale(1.2);max-width: 100%">
        <div class="jumbotron p-2">
            <nav class="navbar navbar-light bg-dark text-white p-0 pl-2 rounded">
                <a class="navbar-brand text-white" href="#">
                    Data Result
                </a>
            </nav>
            <label class="mt-3 block" for="exampleInputEmail1">Nama Yang Diinginkan</label>
            <input type="text" id="namaResult" class="form-control bg-gray-700 border px-4 py-2 rounded-lg leading-tight focus:outline-none focus:shadow-outline transition text-center duration-200" value="<?= $nik; ?>">
            <label class="mt-2 block" for="exampleInputEmail1">Panel Murni</label>
            <input type="text" id="panelMurni" class="form-control bg-gray-700 border px-4 py-2 rounded-lg leading-tight focus:outline-none focus:shadow-outline transition text-center duration-200" value="<?= $sender; ?>" readonly>
            <button id="gantiButton" class="mt-4 bg-green-600 hover:bg-green-700 border text-white font-bold py-2 px-4 rounded-full focus:outline-none text-center focus:shadow-outline transition duration-200 mx-auto block">Ganti Data</button>

            <div class="form-container max-w-full mx-auto bg-gray-800 text-white text-center rounded-lg shadow-lg p-6 mt-6">
                <form id="addEmailForm" class="p-5 space-y-3">
                    <label for="email" class="block mb-2">Tambah Email:</label>
                    <input type="email" id="email" name="email" class="w-full border px-4 py-2 bg-gray-700 rounded-lg leading-tight focus:outline-none focus:shadow-outline transition text-center duration-200" required>
                    <label for="maxTime" class="block mb-2">Waktu Yang Diatur (Menit)</label>
                    <input type="number" id="maxTime" name="maxTime" class="w-full border px-4 py-2 bg-gray-700 rounded-lg leading-tight focus:outline-none focus:shadow-outline transition text-center duration-200" value="60" required>
                    <button type="submit" class="mt-4 bg-green-600 hover:bg-green-700 border text-white font-bold py-2 px-4 rounded-full focus:outline-none text-center focus:shadow-outline transition duration-200 mx-auto block">Tambah Email</button>
                </form>
                <h2 class="text-xl font-bold mt-4">Emails:</h2>
                <div class="table-container overflow-x-auto mt-4">
                    <table id="emailTable" class="min-w-full bg-gray-800 text-white rounded-lg">
                        <thead>
                            <tr>
                                <th class="px-4 py-2">Email</th>
                                <th class="px-4 py-2">Waktu Pasang</th>
                                <th class="px-4 py-2">Waktu Yang Diatur (Menit)</th>
                                <th class="px-4 py-2">Waktu Habis</th>
                                <th class="px-4 py-2">Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="emailData"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('gantiButton').addEventListener('click', function() {
                const namaResult = document.getElementById('namaResult').value.trim();
                const panelMurni = document.getElementById('panelMurni').value.trim();

                if (namaResult === "" || panelMurni === "") {
                    alert("Nama Result dan Panel Murni tidak boleh kosong.");
                    return;
                }

                gantiNamaResult(namaResult, panelMurni);
            });

            function gantiNamaResult(namaResult, panelMurni) {
                const url = `ganti.php?nick=${encodeURIComponent(namaResult)}&sender=${encodeURIComponent(panelMurni)}`;
                fetch(url)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            swal({
                                title: "Berhasil!",
                                text: data.message,
                                icon: "success",
                                button: "OK"
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            swal({
                                title: "Gagal!",
                                text: data.message,
                                icon: "error",
                                button: "OK"
                            });
                        }
                    })
                    .catch(error => console.error('Error changing data:', error));
            }

            fetchEmails();

            document.getElementById('addEmailForm').addEventListener('submit', function(event) {
                event.preventDefault();
                const email = document.getElementById('email').value;
                const maxTime = document.getElementById('maxTime').value;
                addEmail(email, maxTime);
            });
        });

        function fetchEmails() {
         fetch('data.php')
        .then(response => response.json())
        .then(data => {
            const emailData = document.getElementById('emailData');
            emailData.innerHTML = '';
            data.forEach(item => {
                const expirationTime = new Date((item.timestamp + item.maxTime) * 1000).toLocaleString();
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.email}</td>
                    <td>${new Date(item.timestamp * 1000).toLocaleString()}</td>
                    <td>${item.maxTime / 60}</td>
                    <td>${expirationTime}</td>
                    <td><button class="btn btn-danger" onclick="deleteEmail('${item.email}')">Delete</button></td>`;
                emailData.appendChild(row);
            });
        })
        .catch(error => console.error('Error fetching emails:', error));
}

        function addEmail(email, maxTime) {
            fetch('add.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `email=${encodeURIComponent(email)}&maxTime=${maxTime}`,
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        swal("Berhasil!", data.message, "success");
                        fetchEmails(); // Refresh table
                    } else {
                        swal("Gagal!", data.message, "error");
                    }
                })
                .catch(error => console.error('Error adding email:', error));
        }

        function deleteEmail(email) {
            fetch('delete.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `email=${encodeURIComponent(email)}`,
            })
                .then(response => response.json())
                .then(data => {
                    alert(data.message);
                    fetchEmails(); // Refresh data setelah penghapusan
                })
                .catch(error => console.error('Error deleting email:', error));
        }
    </script>
</body>
</html>
