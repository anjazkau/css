<?php 
$nik = "WEB HATSU HOST ||";
$sender = "admin@hatsu.co.id";
?>