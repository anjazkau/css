<?php
$read = file_get_contents('data.json');
$json = json_decode($read, true);
echo count($json);
?>