<?php 
$nik = "WEB HATSU HOST II";
$sender = "support@hatsu.co.id";
?>